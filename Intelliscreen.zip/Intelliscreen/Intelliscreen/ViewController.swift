//
//  ViewController.swift
//  Intelliscreen
//
//  Created by Antonio Adrian Chavez on 4/26/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var LockIcon: UILabel!

    @IBOutlet weak var PowerIcon: UILabel!
    
    @IBOutlet weak var CameraIcon: UILabel!
    
    
    @IBOutlet weak var MailTableView: UITableView!
    @IBOutlet weak var UITableView: UITableView!
    
    // Mail
    
    let MailsTitle = ["Medium Daily Digest", "YouTube", "TestFlight", "WEBTOON Update", "Rebeloper", "Call of Duty", "Call of Duty"]
    
    let MailName = ["Mail", "Mail", "Mail", "Mail", "Mail", "Mail", "Mail", "Mail"]
    
    let statements = ["Donald Trump, American Idiot | umair haque in Eudaimonia and Co", "Donald Trump, American Idiot | umair haque in Eudaimonia and Co", "#StayHome and watch The Creator Games presented by MrBeast!", "GitHub 1.1.1 (3365032) for iOS is now available to test.", "Murrz Ep. 361 - Key to Happiness has been updated!", "💌 Send Email Programmatically in Swift", "This Weekend Only: Free Multiplayer! 🎉", "💌 Send Email Programmatically in Swift", "This Weekend Only: Free Multiplayer! 🎉", "Donald Trump, American Idiot | umair haque in Eudaimonia and Co","Donald Trump, American Idiot | umair haque in Eudaimonia and Co",]
    
    // Alert
    let app_Icon = ["", "", "Anaisa", "Christian", "Joshua", "Image-1", "Image-2", "Image-1",]
    
    let AppName =  ["", "", "Anaisa Tamburo", "ChristianSelig replied", "Joshua Smith", "Trending on r/swift", "WillRBishop", "Trending on r/explainlikeimfive"]
    
    let titleApp = ["", "", "Joshua Smith", "ChristianSelig replied", "Rayan Khan", "Trending on r/swift", "Rudrank Riyam Tweeted", "Trending on r/explainlikeimfive"]
    
    let statementsApp = ["", "", "I love you so much, Baby! ❤️❤️❤️ I can't wait to see you soon!", "Oh my gosh! Great eye Antonio thank you so much for telling me!",  "Oh, That iOS 16 Lockscreen Conecpt looks amazing, bro!", "I made this cool title wave design for a client. Just though people would enjoy!",  "AsyncImage with animation. Love the way those images pop up while scrolling!", "ELI5: In movies where you see a toddler/baby crying and it clearly isn't a doll, how do the filmmakers get the kid to cry in a way that isn't horrible mistreatment?"]
    
    let time = ["", "", "now", "1m ago", "3m ago", "Fri 2:30 PM", "Thurs 2:30 PM", "Mon 2:30 PM"]
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        let blurEffect = UIBlurEffect(style: .light)
        let blurView = UIVisualEffectView(effect: blurEffect)
        blurView.clipsToBounds = true
        blurView.layer.borderColor = UIColor.black.withAlphaComponent(0.4).cgColor
        blurView.layer.borderWidth = 1.0
        blurView.layer.cornerRadius = 6.0

      
        
        
        let headerView = UIView()
          let footerView = UIView()
               
        headerView.backgroundColor = .clear
        footerView.backgroundColor = .clear
               
          let sizeView = CGRect(x: 0, y: 0, width: view.frame.width, height: 4)
               
          headerView.frame = sizeView
          footerView.frame = sizeView
        
           MailTableView.tableHeaderView = headerView
        UITableView.tableHeaderView = headerView
        
        
        // Face ID Icon
        
        let imageAttachment = NSTextAttachment()
        imageAttachment.image = UIImage(systemName: "lock.fill", withConfiguration: UIImage.SymbolConfiguration(pointSize: 30, weight: .regular))?.withTintColor(UIColor.white.withAlphaComponent(0.5))
        
        // Weather SF Present
        let imageAttachment1 = NSTextAttachment()
        imageAttachment1.image = UIImage(systemName: "cloud.sun.fill", withConfiguration: UIImage.SymbolConfiguration(pointSize: 25, weight: .regular))?.withTintColor(UIColor.white.withAlphaComponent(0.5))
        
        let imageAttachment2 = NSTextAttachment()
        imageAttachment2.image = UIImage(systemName: "sparkles", withConfiguration: UIImage.SymbolConfiguration(pointSize: 17, weight: .regular))?.withTintColor(UIColor.white.withAlphaComponent(0.5))
        
        let imageAttachment3 = NSTextAttachment()
        imageAttachment3.image = UIImage(systemName: "cloud.moon.fill", withConfiguration: UIImage.SymbolConfiguration(pointSize: 17, weight: .regular))?.withTintColor(UIColor.white.withAlphaComponent(0.5))
        
        let imageAttachment4 = NSTextAttachment()
        imageAttachment4.image = UIImage(systemName: "sunrise.fill", withConfiguration: UIImage.SymbolConfiguration(pointSize: 17, weight: .regular))?.withTintColor(UIColor.white.withAlphaComponent(0.5))
        
        let imageAttachment5 = NSTextAttachment()
        imageAttachment5.image = UIImage(systemName: "sun.max.fill", withConfiguration: UIImage.SymbolConfiguration(pointSize: 17, weight: .regular))?.withTintColor(UIColor.white.withAlphaComponent(0.5))
        
        let imageAttachment6 = NSTextAttachment()
        imageAttachment6.image = UIImage(systemName: "flashlight.off.fill", withConfiguration: UIImage.SymbolConfiguration(pointSize: 25, weight: .regular))?.withTintColor(UIColor.white.withAlphaComponent(0.2))
        
        
        let imageAttachment7 = NSTextAttachment()
               imageAttachment7.image = UIImage(systemName: "camera.fill", withConfiguration: UIImage.SymbolConfiguration(pointSize: 25, weight: .regular))?.withTintColor(UIColor.white.withAlphaComponent(0.2))
        
        
        let fullString = NSMutableAttributedString(attributedString: NSAttributedString(attachment: imageAttachment))
        let fullString1 = NSMutableAttributedString(attributedString: NSAttributedString(attachment: imageAttachment1))
         let fullString2 = NSMutableAttributedString(attributedString: NSAttributedString(attachment: imageAttachment2))
        
        let fullString3 = NSMutableAttributedString(attributedString: NSAttributedString(attachment: imageAttachment3))
        let fullString4 = NSMutableAttributedString(attributedString: NSAttributedString(attachment: imageAttachment4))
        
        let fullString5 = NSMutableAttributedString(attributedString: NSAttributedString(attachment: imageAttachment5))
        
        let fullString6 = NSMutableAttributedString(attributedString: NSAttributedString(attachment: imageAttachment6))
        
        let fullString7 = NSMutableAttributedString(attributedString: NSAttributedString(attachment: imageAttachment7))
        
        
        
        LockIcon.attributedText = fullString
        
//        PresentWeather.attributedText = fullString1
//
//        OneOne_PM.attributedText = fullString2
//        TwoAM.attributedText = fullString3
//        fiveAM.attributedText = fullString4
//
//        eightAM.attributedText = fullString5
        
        PowerIcon.attributedText = fullString6
        
        CameraIcon.attributedText = fullString7
        
    }


}



extension ViewController: UITableViewDataSource, UITableViewDelegate {
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return app_Icon.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cellToReturn = UITableViewCell()
        
         if tableView == UITableView,
               
            let cells = tableView.dequeueReusableCell(withIdentifier: "Cells") as? NotifictionsAlertCells {
            
            cells.AppName.text = AppName[indexPath.row].uppercased()
            cells.Statements.text = statementsApp[indexPath.row]
            cells.Time.text = time[indexPath.row]
            cells.Icons.image = UIImage(named: app_Icon[indexPath.row])
            cells.ViewBackground.layer.cornerRadius = 20
            cells.ViewBackground.layer.cornerCurve = .continuous
            cells.ViewBackground.layer.masksToBounds = true
                   
            
            if indexPath.row == 0 {
                
                cells.BlurBackground.isHidden = true
                
            } else if indexPath.row == 1 {
                
                cells.BlurBackground.isHidden = true
                
                let backgroundView = UIView()
                backgroundView.frame = CGRect(x: 13, y: 11, width: 366, height: 175)
                
                backgroundView.layer.cornerRadius = 20
                backgroundView.layer.cornerCurve = .continuous
                backgroundView.layer.masksToBounds = true
                
                // Create a gradient layer.
                let gradientLayer = CAGradientLayer()
                // Set the size of the layer to be equal to size of the display.
                gradientLayer.frame = backgroundView.bounds
                // Set an array of Core Graphics colors (.cgColor) to create the gradient.
                // This example uses a Color Literal and a UIColor from RGB values.
                gradientLayer.colors = [#colorLiteral(red: 0.03919353336, green: 0.4467189312, blue: 0.6261560917, alpha: 1).cgColor, #colorLiteral(red: 0.2143383622, green: 0.7760617137, blue: 1, alpha: 1).cgColor]
                // Rasterize this static layer to improve app performance.
                gradientLayer.shouldRasterize = true
             
             // Diagonal: top left to bottom corner.
             gradientLayer.startPoint = CGPoint(x: 1, y: 1) // Top left corner.
             gradientLayer.endPoint = CGPoint(x: 0, y: 0) // Bottom right corner.
             
                // Apply the gradient to the backgroundGradientView.
                backgroundView.layer.addSublayer(gradientLayer)
                
                
          
                let weatherView = UIView()
                let LabelLocation = UILabel()
                LabelLocation.text = "Great Bend"
                LabelLocation.frame = CGRect(x: 16, y: 14, width: 176, height: 21)
                LabelLocation.font = UIFont.systemFont(ofSize: 17, weight: .semibold)
                
                let widgetsName = UILabel()
                widgetsName.text = "Weather"
                widgetsName.font = UIFont.systemFont(ofSize: 13, weight: .regular)
                widgetsName.frame = CGRect(x: 13, y: 194, width: 366, height: 21)
                widgetsName.textAlignment = .center
                
                let LabelTemp = UILabel()
                LabelTemp.text = "80°"
                LabelTemp.frame = CGRect(x: 16, y: 43, width: 176, height: 35)
                LabelTemp.font = UIFont.systemFont(ofSize: 40, weight: .light)
                
                let SFWeatherToday = UIImageView()
                SFWeatherToday.image = UIImage(named: "Sunny")
                SFWeatherToday.frame = CGRect(x: 329, y: 14, width: 21, height: 21)
               
                
                let LabelWeatherToday = UILabel()
                LabelWeatherToday.text = "Sunny"
                LabelWeatherToday.font = UIFont.systemFont(ofSize: 13, weight: .regular)
                LabelWeatherToday.frame = CGRect(x: 246, y: 36, width: 104, height: 21)
                LabelWeatherToday.textAlignment = .right
                
                
                
                let LabalTempToday = UILabel()
                LabalTempToday.text = "H: 90° L: 50°"
                LabalTempToday.font = UIFont.systemFont(ofSize: 13, weight: .regular)
                LabalTempToday.frame = CGRect(x: 246, y: 54, width: 104, height: 21)
                LabalTempToday.textAlignment = .right
                
                
                let OneHR = UILabel()
                OneHR.text = "2PM"
                OneHR.frame = CGRect(x: 8, y: 89, width: 53, height: 21)
                OneHR.font = UIFont.systemFont(ofSize: 13, weight: .semibold)
                OneHR.alpha = 0.5
                OneHR.textAlignment = .center
                
                
                let OneW = UIImageView()
                OneW.image = UIImage(named: "Sunny")
                OneW.frame = CGRect(x: 19, y: 111, width: 30, height: 30)
                
                let OneTemp = UILabel()
                OneTemp.text = "50°"
                OneTemp.frame = CGRect(x: 8, y: 142, width: 53, height: 21)
                OneTemp.font = UIFont.systemFont(ofSize: 13, weight: .semibold)
                OneTemp.alpha = 0.5
                OneTemp.textAlignment = .center
                
        
                let TwoHR = UILabel()
                TwoHR.text = "3PM"
                TwoHR.frame = CGRect(x: 83, y: 89, width: 53, height: 21)
                TwoHR.font = UIFont.systemFont(ofSize: 13, weight: .semibold)
                TwoHR.alpha = 0.5
                TwoHR.textAlignment = .center
                
                
                let TwoW = UIImageView()
                TwoW.image = UIImage(named: "Sunny")
                TwoW.frame = CGRect(x: 95, y: 111, width: 30, height: 30)
                
                let TwoTemp = UILabel()
                TwoTemp.text = "50°"
                TwoTemp.frame = CGRect(x: 83, y: 141, width: 53, height: 21)
                TwoTemp.font = UIFont.systemFont(ofSize: 13, weight: .semibold)
                TwoTemp.alpha = 0.5
                TwoTemp.textAlignment = .center
                
                let ThreeHR = UILabel()
                ThreeHR.text = "4PM"
                ThreeHR.frame = CGRect(x: 157, y: 89, width: 53, height: 21)
                ThreeHR.font = UIFont.systemFont(ofSize: 13, weight: .semibold)
                ThreeHR.alpha = 0.5
                ThreeHR.textAlignment = .center
                
                let ThreeW = UIImageView()
                ThreeW.image = UIImage(named: "Sunny")
                ThreeW.frame = CGRect(x: 168, y: 111, width: 30, height: 30)
                
                let ThreeTemp = UILabel()
                ThreeTemp.text = "50°"
                ThreeTemp.frame = CGRect(x: 157, y: 142, width: 53, height: 21)
                ThreeTemp.font = UIFont.systemFont(ofSize: 13, weight: .semibold)
                ThreeTemp.alpha = 0.5
                ThreeTemp.textAlignment = .center
                
                let FourHR = UILabel()
                FourHR.text = "5PM"
                FourHR.frame = CGRect(x: 230, y: 89, width: 53, height: 21)
                FourHR.font = UIFont.systemFont(ofSize: 13, weight: .semibold)
                FourHR.alpha = 0.5
                FourHR.textAlignment = .center
                
                let FourW = UIImageView()
                FourW.image = UIImage(named: "Sunny")
                FourW.frame = CGRect(x: 242, y: 111, width: 30, height: 30)
                
                let FourTemp = UILabel()
                FourTemp.text = "50°"
                FourTemp.frame = CGRect(x: 230, y: 142, width: 53, height: 21)
                FourTemp.font = UIFont.systemFont(ofSize: 13, weight: .semibold)
                FourTemp.alpha = 0.5
                FourTemp.textAlignment = .center
                
                let FiveHR = UILabel()
                FiveHR.text = "6PM"
                FiveHR.frame = CGRect(x: 304, y: 89, width: 53, height: 21)
                FiveHR.font = UIFont.systemFont(ofSize: 13, weight: .semibold)
                FiveHR.alpha = 0.5
                FiveHR.textAlignment = .center
                
                let FiveW = UIImageView()
                FiveW.image = UIImage(named: "Sunny")
                FiveW.frame = CGRect(x: 315, y: 111, width: 30, height: 30)
                
                let FiveTemp = UILabel()
                FiveTemp.text = "50°"
                FiveTemp.frame = CGRect(x: 304, y: 142, width: 53, height: 21)
                FiveTemp.font = UIFont.systemFont(ofSize: 13, weight: .semibold)
                FiveTemp.alpha = 0.5
                FiveTemp.textAlignment = .center
                
                
                cells.addSubview(backgroundView)
                cells.addSubview(weatherView)
                
                backgroundView.addSubview(LabelLocation)
                backgroundView.addSubview(LabelTemp)
                
                backgroundView.addSubview(SFWeatherToday)
                backgroundView.addSubview(LabelWeatherToday)
                backgroundView.addSubview(LabalTempToday)
                
                
                backgroundView.addSubview(OneHR)
                backgroundView.addSubview(OneW)
                backgroundView.addSubview(OneTemp)
                
                backgroundView.addSubview(TwoHR)
                backgroundView.addSubview(TwoW)
                backgroundView.addSubview(TwoTemp)
                
                backgroundView.addSubview(ThreeHR)
                backgroundView.addSubview(ThreeW)
                backgroundView.addSubview(ThreeTemp)
                
                backgroundView.addSubview(FourHR)
                backgroundView.addSubview(FourW)
                backgroundView.addSubview(FourTemp)
                
                backgroundView.addSubview(FiveHR)
                backgroundView.addSubview(FiveW)
                backgroundView.addSubview(FiveTemp)
                
                cells.addSubview(widgetsName)
                
                
            }
            
            
            cellToReturn = cells
            

            } else if tableView == MailTableView,
            
                let twoCells = tableView.dequeueReusableCell(withIdentifier: "NewsCells") as? NewsCellsTableViewCell {
                
                twoCells.MailName.text = MailName[indexPath.row].uppercased()
                twoCells.MailTitle.text = MailsTitle[indexPath.row]
                twoCells.StatementsMail.text = statements[indexPath.row]
                
                  cellToReturn = twoCells
            }

            return cellToReturn
        }

        
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
       
        if indexPath.row == 7 {
            return 95
        } else if indexPath.row == 6 {
            return 95
        } else if indexPath.row == 5 {
                return 95
        } else if indexPath.row == 4 {
            return 95
        } else if indexPath.row == 3 {
                return 95
        } else if indexPath.row == 2 {
               return 95
        } else if indexPath.row == 1 {
               return 226
       } else {
               return 164
        }
        
    }
    
    
    
}
