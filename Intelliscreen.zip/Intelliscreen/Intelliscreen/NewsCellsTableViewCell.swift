//
//  NewsCellsTableViewCell.swift
//  Intelliscreen
//
//  Created by Antonio Adrian Chavez on 4/26/20.
//  Copyright © 2020 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class NewsCellsTableViewCell: UITableViewCell {

    @IBOutlet weak var MailIcons: UIImageView!
    @IBOutlet weak var MailName: UILabel!
    @IBOutlet weak var MailTitle: UILabel!
    @IBOutlet weak var StatementsMail: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
