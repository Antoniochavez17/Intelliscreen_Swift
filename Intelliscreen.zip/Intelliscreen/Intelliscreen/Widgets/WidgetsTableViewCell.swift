//
//  WidgetsTableViewCell.swift
//  Intelliscreen
//
//  Created by Antonio Adrian Chavez on 6/13/21.
//  Copyright © 2021 Antonio Adrian Chavez. All rights reserved.
//

import UIKit

class WidgetsTableViewCell: UITableViewCell {

    @IBOutlet weak var BackgroundVIew: UIView!
    @IBOutlet weak var WeatherBackground: UIView!
    
    
    @IBOutlet weak var LabelLocation: UILabel!
    @IBOutlet weak var LabelTemp: UILabel!
    
    @IBOutlet weak var SFWeatherToday: UILabel!
    @IBOutlet weak var LabelWeatherToday: UILabel!
    @IBOutlet weak var LabalTempToday: UILabel!
    
    @IBOutlet weak var OneHR: UILabel!
    @IBOutlet weak var OneW: UILabel!
    @IBOutlet weak var OneTemp: UILabel!
    
    
    @IBOutlet weak var TwoHR: UILabel!
    @IBOutlet weak var TwoW: UILabel!
    
    
    @IBOutlet weak var ThreeHR: UILabel!
    @IBOutlet weak var ThreeW: UILabel!
    @IBOutlet weak var ThreeTemp: UILabel!
    
    @IBOutlet weak var FourHR: UILabel!
    @IBOutlet weak var FourW: UILabel!
    @IBOutlet weak var FourTemp: UILabel!
    
    
    @IBOutlet weak var FiveHR: UILabel!
    @IBOutlet weak var FiveW: UILabel!
    @IBOutlet weak var FiveTemp: UILabel!
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
